﻿#region License
// 
// Copyright (c) 2013, Kooboo team
// 
// Licensed under the BSD License
// See the file LICENSE.txt for details.
// 
#endregion
using System.Reflection;
[assembly: AssemblyProduct("Kooboo.Commerce")]
[assembly: AssemblyCompany("Yardi Technology Limited")]
[assembly: AssemblyCopyright("Copyright © Yari 2009-2013")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.0.0.0527")]
[assembly: AssemblyFileVersion("1.0.0.0527")]
