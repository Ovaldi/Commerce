﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Kooboo.Commerce.Models.Orders;

namespace Kooboo.Commerce.Persistence
{
    public interface IOrderProvider:IProvider<Order>
    {
        
    }
}
